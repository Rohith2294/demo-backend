const MainuserModel = require('./../modal/MainUsersModel')
var jwt = require('jsonwebtoken')
const date = require("date-and-time");
const bcrypt = require("bcrypt");
exports.signup = async (req, res) => {
    const email = req.body.email
    const password = req.body.password
    const name = req.body.name
    const phonenumber = req.body.phonenumber
    const gender = req.body.gender
    if (!email || !password || !phonenumber ) {
        return res.status(400).json({ error: "Enter All Fields" })
    }else if(phonenumber !==Number){
        return res.status(400).json({ error: "phone number should be in number format" })
    }else {
        let date1 = new Date();
        let now = date.format(date1, "YYYY-MM-DDTHH:mm:ss");
        const bcryptPassword = await bcrypt.hash(password, 7);
        const findEmail = await MainuserModel.findOne({ email: email })
        if (findEmail) {
            return res.status(401).json({ error: `a user already registered with this id ${email}` })
        } else {
            const MainUserData = {
                name:name,
                email: email,
                password: bcryptPassword,
                phonenumber: phonenumber,
                gender: gender,
                CreatedTime: now,
                Active: 1,
            }
            await MainuserModel.insertMany([MainUserData]).then(async (userData) => {
                console.log(userData, 'UserData')
                res.status(200).json({ message: 'Registration Successfull', userData })
            });

        }
    }
}
exports.Login = async (req, res) => {
    const email = req.body.email
    const password = req.body.password

    let loginuserData
    if (!email || !password) {
        return res.status(400).json({ error: "Enter All Fields" })
    }
    await MainuserModel.findOne({ email: email,Active:1 }).then((userData) => {
        if (!userData) {
            return res.status(401).json({ error: "Email Not Found" })
        }
        loginuserData = userData

        return bcrypt.compare(password, userData.password);
    }).then(async (userdetails) => {
        if (!userdetails) {
            return res.status(401).json({ error: "Wrong Password !" });
        } else {
            if (loginuserData) {
                console.log(loginuserData, 'loginuserData')
                const token = jwt.sign(
                    { email: loginuserData.email, userId: loginuserData._id.toString() },
                    "secretKey",
                )
                if (token) {
                    loginuserData.token = token
                    await loginuserData.save()
                }
                res
                .status(200)
                .json({message:"Login Successfully",
                    token: loginuserData.token,
                    userDetails: loginuserData,
                });
            }

        }
    })


}